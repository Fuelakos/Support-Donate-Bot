Make an application here: https://discord.com/developers/applications/

copy the token

Extract the bot files into desktop

Copy the token to the bot's config (config.json)

copy your bots client id paste it here : https://discordapi.com/permissions.html and select administrator permissions!

Then click the link and add it to your discord server!

Open you cmd and type =>

cd desktop
cd wfs-donate
node .

You bot will come online!

Type in a text channel !setup and you are ready! 

Have Fun!


=============================================================================
=============================================================================

YOU CAN ALSO CHECK THE INSTALLATION HERE => https://streamable.com/v6st4h